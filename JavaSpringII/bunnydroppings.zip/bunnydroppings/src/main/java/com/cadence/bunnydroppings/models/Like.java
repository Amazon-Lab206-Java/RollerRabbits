package com.cadence.bunnydroppings.models;
@Entity
@
public class Like {

}
