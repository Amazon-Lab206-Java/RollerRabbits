package com.cadence.bunnydroppings.repo;

public interface RoleRepository {

}
