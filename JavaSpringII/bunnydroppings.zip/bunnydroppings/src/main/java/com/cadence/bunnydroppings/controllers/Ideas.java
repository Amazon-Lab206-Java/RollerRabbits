package com.cadence.bunnydroppings.controllers;

public class Ideas {

}
